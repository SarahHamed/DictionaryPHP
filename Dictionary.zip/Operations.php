<?php
    interface Operations{
        public function Add();
        public function Update();
        public function Delete();
        public function GetAll();
    }
?>